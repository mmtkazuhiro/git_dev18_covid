<?php

require_once('funcs.php');

//1. POSTデータ取得
    $saitama_infected = $_POST['saitama_infected'];
    $saitama_injured = $_POST['saitama_injured'];
    $saitama_bed = $_POST['saitama_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        saitama_infected = :saitama_infected,
                        saitama_injured = :saitama_injured,
                        saitama_bed = :saitama_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':saitama_infected', $saitama_infected, PDO::PARAM_INT); 
$stmt->bindValue(':saitama_injured', $saitama_injured, PDO::PARAM_INT);
$stmt->bindValue(':saitama_bed', $saitama_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('saitama.php');
}
