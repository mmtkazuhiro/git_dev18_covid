<!-- <?php
if(!isset($SESSION_['hokkaido_infected'])) {
    $SESSION_['hokkaido_infected'] = 0;
    } else {
    $SESSION_['hokkaido_infected']++;
    }
?> -->

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/covid.css" rel="stylesheet">
    <title>コロナ感染者数 日本地図</title>
</head>
<body>

<div class="outalert">
    <div class="alert">
        <p>病床逼迫率80%を超えると音声が出ますので音量にご注意してください</p>
        <button>OK</button>
    </div>
</div>

<audio id="sound1" preload="auto">
        <source src="audio/mitudesu1.wav" type="audio/wav">
</audio>

<audio id="sound2" preload="auto">
        <source src="audio/mitudesu2.wav" type="audio/wav">
</audio>

<div class="system">新型コロナウイルス　感染者数・重傷者数・病床数　管理システム</div>

    <form action="insert.php" method="POST" name="covid">
        <table class="table">
            <tr class="title">
                <th class="pref">都道府県</th>
                <th class="infec">感染者数</th>
                <th class="inj">重傷者数</th>
                <th class="bed">病床数</th>
                <th class="tight">病床逼迫率*</th>
            </tr>
        
            <tr class="tr">
                <th class="th">北海道</th>
                <td><input type="number" name="hokkaido_infected" id="hokkaido_infected"></td>
                <td><input type="number" name="hokkaido_injured" id="hokkaido_injured"></td>
                <td><input type="number" name="hokkaido_bed" id="hokkaido_bed"></td>
                <td><output type="number" name="hokkaido_tight" id="hokkaido_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">青森県</th>
                <td><input type="number" name="aomori_infected" id="aomori_infected"></td>
                <td><input type="number" name="aomori_injured" id="aomori_injured"></td>
                <td><input type="number" name="aomori_bed" id="aomori_bed"></td>
                <td><output type="number" name="aomori_tight" id="aomori_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">岩手県</th>
                <td><input type="number" name="iwate_infected" id="iwate_infected"></td>
                <td><input type="number" name="iwate_injured" id="iwate_injured"></td>
                <td><input type="number" name="iwate_bed" id="iwate_bed"></td>
                <td><output type="number" name="iwate_tight" id="iwate_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">宮城県</th>
                <td><input type="number" name="miyagi_infected" id="miyagi_infected"></td>
                <td><input type="number" name="miyagi_injured" id="miyagi_injured"></td>
                <td><input type="number" name="miyagi_bed" id="miyagi_bed"></td>
                <td><output type="number" name="miyagi_tight" id="miyagi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">秋田県</th>
                <td><input type="number" name="akita_infected" id="akita_infected"></td>
                <td><input type="number" name="akita_injured" id="akita_injured"></td>
                <td><input type="number" name="akita_bed" id="akita_bed"></td>
                <td><output type="number" name="akita_tight" id="akita_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">山形県</th>
                <td><input type="number" name="yamagata_infected" id="yamagata_infected"></td>
                <td><input type="number" name="yamagata_injured" id="yamagata_injured"></td>
                <td><input type="number" name="yamagata_bed" id="yamagata_bed"></td>
                <td><output type="number" name="yamagata_tight" id="yamagata_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">福島県</th>
                <td><input type="number" name="fukushima_infected" id="fukushima_infected"></td>
                <td><input type="number" name="fukushima_injured" id="fukushima_injured"></td>
                <td><input type="number" name="fukushima_bed" id="fukushima_bed"></td>
                <td><output type="number" name="fukushima_tight" id="fukushima_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">茨城県</th>
                <td><input type="number" name="ibaraki_infected" id="ibaraki_infected"></td>
                <td><input type="number" name="ibaraki_injured" id="ibaraki_injured"></td>
                <td><input type="number" name="ibaraki_bed" id="ibaraki_bed"></td>
                <td><output type="number" name="ibaraki_tight" id="ibaraki_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">栃木県</th>
                <td><input type="number" name="tochigi_infected" id="tochigi_infected"></td>
                <td><input type="number" name="tochigi_injured" id="tochigi_injured"></td>
                <td><input type="number" name="tochigi_bed" id="tochigi_bed"></td>
                <td><output type="number" name="tochigi_tight" id="tochigi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">群馬県</th>
                <td><input type="number" name="gunma_infected" id="gunma_infected"></td>
                <td><input type="number" name="gunma_injured" id="gunma_injured"></td>
                <td><input type="number" name="gunma_bed" id="gunma_bed"></td>
                <td><output type="number" name="gunma_tight" id="gunma_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">埼玉県</th>
                <td><input type="number" name="saitama_infected" id="saitama_infected"></td>
                <td><input type="number" name="saitama_injured" id="saitama_injured"></td>
                <td><input type="number" name="saitama_bed" id="saitama_bed"></td>
                <td><output type="number" name="saitama_tight" id="saitama_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">千葉県</th>
                <td><input type="number" name="chiba_infected" id="chiba_infected"></td>
                <td><input type="number" name="chiba_injured" id="chiba_injured"></td>
                <td><input type="number" name="chiba_bed" id="chiba_bed"></td>
                <td><output type="number" name="chiba_tight" id="chiba_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">東京都</th>
                <td><input type="number" name="tokyo_infected" id="tokyo_infected"></td>
                <td><input type="number" name="tokyo_injured" id="tokyo_injured"></td>
                <td><input type="number" name="tokyo_bed" id="tokyo_bed"></td>
                <td><output type="number" name="tokyo_tight" id="tokyo_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">神奈川県</th>
                <td><input type="number" name="kanagawa_infected" id="kanagawa_infected"></td>
                <td><input type="number" name="kanagawa_injured" id="kanagawa_injured"></td>
                <td><input type="number" name="kanagawa_bed" id="kanagawa_bed"></td>
                <td><output type="number" name="kanagawa_tight" id="kanagawa_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">新潟県</th>
                <td><input type="number" name="niigata_infected" id="niigata_infected"></td>
                <td><input type="number" name="niigata_injured" id="niigata_injured"></td>
                <td><input type="number" name="niigata_bed" id="niigata_bed"></td>
                <td><output type="number" name="niigata_tight" id="niigata_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">富山県</th>
                <td><input type="number" name="toyama_infected" id="toyama_infected"></td>
                <td><input type="number" name="toyama_injured" id="toyama_injured"></td>
                <td><input type="number" name="toyama_bed" id="toyama_bed"></td>
                <td><output type="number" name="toyama_tight" id="toyama_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">石川県</th>
                <td><input type="number" name="ishikawa_infected" id="ishikawa_infected"></td>
                <td><input type="number" name="ishikawa_injured" id="ishikawa_injured"></td>
                <td><input type="number" name="ishikawa_bed" id="ishikawa_bed"></td>
                <td><output type="number" name="ishikawa_tight" id="ishikawa_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">福井県</th>
                <td><input type="number" name="fukui_infected" id="fukui_infected"></td>
                <td><input type="number" name="fukui_injured" id="fukui_injured"></td>
                <td><input type="number" name="fukui_bed" id="fukui_bed"></td>
                <td><output type="number" name="fukui_tight" id="fukui_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">山梨県</th>
                <td><input type="number" name="yamanashi_infected" id="yamanashi_infected"></td>
                <td><input type="number" name="yamanashi_injured" id="yamanashi_injured"></td>
                <td><input type="number" name="yamanashi_bed" id="yamanashi_bed"></td>
                <td><output type="number" name="yamanashi_tight" id="yamanashi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">長野県</th>
                <td><input type="number" name="nagano_infected" id="nagano_infected"></td>
                <td><input type="number" name="nagano_injured" id="nagano_injured"></td>
                <td><input type="number" name="nagano_bed" id="nagano_bed"></td>
                <td><output type="number" name="nagano_tight" id="nagano_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">岐阜県</th>
                <td><input type="number" name="gifu_infected" id="gifu_infected"></td>
                <td><input type="number" name="gifu_injured" id="gifu_injured"></td>
                <td><input type="number" name="gifu_bed" id="gifu_bed"></td>
                <td><output type="number" name="gifu_tight" id="gifu_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">静岡県</th>
                <td><input type="number" name="shizuoka_infected" id="shizuoka_infected"></td>
                <td><input type="number" name="shizuoka_injured" id="shizuoka_injured"></td>
                <td><input type="number" name="shizuoka_bed" id="shizuoka_bed"></td>
                <td><output type="number" name="shizuoka_tight" id="shizuoka_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">愛知県</th>
                <td><input type="number" name="aichi_infected" id="aichi_infected"></td>
                <td><input type="number" name="aichi_injured" id="aichi_injured"></td>
                <td><input type="number" name="aichi_bed" id="aichi_bed"></td>
                <td><output type="number" name="aichi_tight" id="aichi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">三重県</th>
                <td><input type="number" name="mie_infected" id="mie_infected"></td>
                <td><input type="number" name="mie_injured" id="mie_injured"></td>
                <td><input type="number" name="mie_bed" id="mie_bed"></td>
                <td><output type="number" name="mie_tight" id="mie_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">滋賀県</th>
                <td><input type="number" name="shiga_infected" id="shiga_infected"></td>
                <td><input type="number" name="shiga_injured" id="shiga_injured"></td>
                <td><input type="number" name="shiga_bed" id="shiga_bed"></td>
                <td><output type="number" name="shiga_tight" id="shiga_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">京都府</th>
                <td><input type="number" name="kyoto_infected" id="kyoto_infected"></td>
                <td><input type="number" name="kyoto_injured" id="kyoto_injured"></td>
                <td><input type="number" name="kyoto_bed" id="kyoto_bed"></td>
                <td><output type="number" name="kyoto_tight" id="kyoto_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">大阪府</th>
                <td><input type="number" name="osaka_infected" id="osaka_infected"></td>
                <td><input type="number" name="osaka_injured" id="osaka_injured"></td>
                <td><input type="number" name="osaka_bed" id="osaka_bed"></td>
                <td><output type="number" name="osaka_tight" id="osaka_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">兵庫県</th>
                <td><input type="number" name="hyogo_infected" id="hyogo_infected"></td>
                <td><input type="number" name="hyogo_injured" id="hyogo_injured"></td>
                <td><input type="number" name="hyogo_bed" id="hyogo_bed"></td>
                <td><output type="number" name="hyogo_tight" id="hyogo_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">奈良県</th>
                <td><input type="number" name="nara_infected" id="nara_infected"></td>
                <td><input type="number" name="nara_injured" id="nara_injured"></td>
                <td><input type="number" name="nara_bed" id="nara_bed"></td>
                <td><output type="number" name="nara_tight" id="nara_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">和歌山県</th>
                <td><input type="number" name="wakayama_infected" id="wakayama_infected"></td>
                <td><input type="number" name="wakayama_injured" id="wakayama_injured"></td>
                <td><input type="number" name="wakayama_bed" id="wakayama_bed"></td>
                <td><output type="number" name="wakayama_tight" id="wakayama_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">鳥取県</th>
                <td><input type="number" name="tottori_infected" id="tottori_infected"></td>
                <td><input type="number" name="tottori_injured" id="tottori_injured"></td>
                <td><input type="number" name="tottori_bed" id="tottori_bed"></td>
                <td><output type="number" name="tottori_tight" id="tottori_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">島根県</th>
                <td><input type="number" name="shimane_infected" id="shimane_infected"></td>
                <td><input type="number" name="shimane_injured" id="shimane_injured"></td>
                <td><input type="number" name="shimane_bed" id="shimane_bed"></td>
                <td><output type="number" name="shimane_tight" id="shimane_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">岡山県</th>
                <td><input type="number" name="okayama_infected" id="okayama_infected"></td>
                <td><input type="number" name="okayama_injured" id="okayama_injured"></td>
                <td><input type="number" name="okayama_bed" id="okayama_bed"></td>
                <td><output type="number" name="okayama_tight" id="okayama_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">広島県</th>
                <td><input type="number" name="hiroshima_infected" id="hiroshima_infected"></td>
                <td><input type="number" name="hiroshima_injured" id="hiroshima_injured"></td>
                <td><input type="number" name="hiroshima_bed" id="hiroshima_bed"></td>
                <td><output type="number" name="hiroshima_tight" id="hiroshima_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">山口県</th>
                <td><input type="number" name="yamaguchi_infected" id="yamaguchi_infected"></td>
                <td><input type="number" name="yamaguchi_injured" id="yamaguchi_injured"></td>
                <td><input type="number" name="yamaguchi_bed" id="yamaguchi_bed"></td>
                <td><output type="number" name="yamaguchi_tight" id="yamaguchi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">徳島県</th>
                <td><input type="number" name="tokushima_infected" id="tokushima_infected"></td>
                <td><input type="number" name="tokushima_injured" id="tokushima_injured"></td>
                <td><input type="number" name="tokushima_bed" id="tokushima_bed"></td>
                <td><output type="number" name="tokushima_tight" id="tokushima_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">香川県</th>
                <td><input type="number" name="kagawa_infected" id="kagawa_infected"></td>
                <td><input type="number" name="kagawa_injured" id="kagawa_injured"></td>
                <td><input type="number" name="kagawa_bed" id="kagawa_bed"></td>
                <td><output type="number" name="kagawa_tight" id="kagawa_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">愛媛県</th>
                <td><input type="number" name="ehime_infected" id="ehime_infected"></td>
                <td><input type="number" name="ehime_injured" id="ehime_injured"></td>
                <td><input type="number" name="ehime_bed" id="ehime_bed"></td>
                <td><output type="number" name="ehime_tight" id="ehime_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">高知県</th>
                <td><input type="number" name="kochi_infected" id="kochi_infected"></td>
                <td><input type="number" name="kochi_injured" id="kochi_injured"></td>
                <td><input type="number" name="kochi_bed" id="kochi_bed"></td>
                <td><output type="number" name="kochi_tight" id="kochi_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">福岡県</th>
                <td><input type="number" name="fukuoka_infected" id="fukuoka_infected"></td>
                <td><input type="number" name="fukuoka_injured" id="fukuoka_injured"></td>
                <td><input type="number" name="fukuoka_bed" id="fukuoka_bed"></td>
                <td><output type="number" name="fukuoka_tight" id="fukuoka_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">佐賀県</th>
                <td><input type="number" name="saga_infected" id="saga_infected"></td>
                <td><input type="number" name="saga_injured" id="saga_injured"></td>
                <td><input type="number" name="saga_bed" id="saga_bed"></td>
                <td><output type="number" name="saga_tight" id="saga_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">長崎県</th>
                <td><input type="number" name="nagasaki_infected" id="nagasaki_infected"></td>
                <td><input type="number" name="nagasaki_injured" id="nagasaki_injured"></td>
                <td><input type="number" name="nagasaki_bed" id="nagasaki_bed"></td>
                <td><output type="number" name="nagasaki_tight" id="nagasaki_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">熊本県</th>
                <td><input type="number" name="kumamoto_infected" id="kumamoto_infected"></td>
                <td><input type="number" name="kumamoto_injured" id="kumamoto_injured"></td>
                <td><input type="number" name="kumamoto_bed" id="kumamoto_bed"></td>
                <td><output type="number" name="kumamoto_tight" id="kumamoto_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">大分県</th>
                <td><input type="number" name="oita_infected" id="oita_infected"></td>
                <td><input type="number" name="oita_injured" id="oita_injured"></td>
                <td><input type="number" name="oita_bed" id="oita_bed"></td>
                <td><output type="number" name="oita_tight" id="oita_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">宮崎県</th>
                <td><input type="number" name="miyazaki_infected" id="miyazaki_infected"></td>
                <td><input type="number" name="miyazaki_injured" id="miyazaki_injured"></td>
                <td><input type="number" name="miyazaki_bed" id="miyazaki_bed"></td>
                <td><output type="number" name="miyazaki_tight" id="miyazaki_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">鹿児島県</th>
                <td><input type="number" name="kagoshima_infected" id="kagoshima_infected"></td>
                <td><input type="number" name="kagoshima_injured" id="kagoshima_injured"></td>
                <td><input type="number" name="kagoshima_bed" id="kagoshima_bed"></td>
                <td><output type="number" name="kagoshima_tight" id="kagoshima_tight"></td>
            </tr>

            <tr class="tr">
                <th class="th">沖縄県</th>
                <td><input type="number" name="okinawa_infected" id="okinawa_infected"></td>
                <td><input type="number" name="okinawa_injured" id="okinawa_injured"></td>
                <td><input type="number" name="okinawa_bed" id="okinawa_bed"></td>
                <td><output type="number" name="okinawa_tight" id="okinawa_tight"></td>
            </tr>

        </table>

        <div class="note">*病床逼迫率...ここでは病床数に対する重傷者数を病床逼迫率としています。</div>

        <div class="outsend"><input type="submit" value="送信" class="send"></div>
        <div class="outoutlook">
            <div class="outlook"><a href="select.php" class="look">送信せずに結果を見る</a></div>
        </div>
    </form>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- ポップアップ画面を1回しか表示させないようにするためのCDN jquery-cookie-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>

<script src="js/covid.js"></script>

</body>
</html>