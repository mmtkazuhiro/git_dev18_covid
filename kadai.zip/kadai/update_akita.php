<?php

require_once('funcs.php');

//1. POSTデータ取得
    $akita_infected = $_POST['akita_infected'];
    $akita_injured = $_POST['akita_injured'];
    $akita_bed = $_POST['akita_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        akita_infected = :akita_infected,
                        akita_injured = :akita_injured,
                        akita_bed = :akita_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':akita_infected', $akita_infected, PDO::PARAM_INT); 
$stmt->bindValue(':akita_injured', $akita_injured, PDO::PARAM_INT);
$stmt->bindValue(':akita_bed', $akita_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('akita.php');
}
