<?php

require_once('funcs.php');

//1. POSTデータ取得
    $yamagata_infected = $_POST['yamagata_infected'];
    $yamagata_injured = $_POST['yamagata_injured'];
    $yamagata_bed = $_POST['yamagata_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        yamagata_infected = :yamagata_infected,
                        yamagata_injured = :yamagata_injured,
                        yamagata_bed = :yamagata_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':yamagata_infected', $yamagata_infected, PDO::PARAM_INT); 
$stmt->bindValue(':yamagata_injured', $yamagata_injured, PDO::PARAM_INT);
$stmt->bindValue(':yamagata_bed', $yamagata_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('yamagata.php');
}
