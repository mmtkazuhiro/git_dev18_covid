<?php

require_once('funcs.php');

//1. POSTデータ取得
    $wakayama_infected = $_POST['wakayama_infected'];
    $wakayama_injured = $_POST['wakayama_injured'];
    $wakayama_bed = $_POST['wakayama_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        wakayama_infected = :wakayama_infected,
                        wakayama_injured = :wakayama_injured,
                        wakayama_bed = :wakayama_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':wakayama_infected', $wakayama_infected, PDO::PARAM_INT); 
$stmt->bindValue(':wakayama_injured', $wakayama_injured, PDO::PARAM_INT);
$stmt->bindValue(':wakayama_bed', $wakayama_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('wakayama.php');
}
