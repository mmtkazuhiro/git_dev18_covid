<?php

require_once('funcs.php');

//1. POSTデータ取得
    $shimane_infected = $_POST['shimane_infected'];
    $shimane_injured = $_POST['shimane_injured'];
    $shimane_bed = $_POST['shimane_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        shimane_infected = :shimane_infected,
                        shimane_injured = :shimane_injured,
                        shimane_bed = :shimane_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':shimane_infected', $shimane_infected, PDO::PARAM_INT); 
$stmt->bindValue(':shimane_injured', $shimane_injured, PDO::PARAM_INT);
$stmt->bindValue(':shimane_bed', $shimane_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('shimane.php');
}
