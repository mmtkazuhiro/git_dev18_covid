<?php

require_once('funcs.php');

//1. POSTデータ取得
    $aichi_infected = $_POST['aichi_infected'];
    $aichi_injured = $_POST['aichi_injured'];
    $aichi_bed = $_POST['aichi_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        aichi_infected = :aichi_infected,
                        aichi_injured = :aichi_injured,
                        aichi_bed = :aichi_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':aichi_infected', $aichi_infected, PDO::PARAM_INT); 
$stmt->bindValue(':aichi_injured', $aichi_injured, PDO::PARAM_INT);
$stmt->bindValue(':aichi_bed', $aichi_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('aichi.php');
}
