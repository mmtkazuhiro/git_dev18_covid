<?php

require_once('funcs.php');

//1. POSTデータ取得
    $yamanashi_infected = $_POST['yamanashi_infected'];
    $yamanashi_injured = $_POST['yamanashi_injured'];
    $yamanashi_bed = $_POST['yamanashi_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        yamanashi_infected = :yamanashi_infected,
                        yamanashi_injured = :yamanashi_injured,
                        yamanashi_bed = :yamanashi_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':yamanashi_infected', $yamanashi_infected, PDO::PARAM_INT); 
$stmt->bindValue(':yamanashi_injured', $yamanashi_injured, PDO::PARAM_INT);
$stmt->bindValue(':yamanashi_bed', $yamanashi_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('yamanashi.php');
}
