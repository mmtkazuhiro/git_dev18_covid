<?php

require_once('funcs.php');

//1. POSTデータ取得
    $kanagawa_infected = $_POST['kanagawa_infected'];
    $kanagawa_injured = $_POST['kanagawa_injured'];
    $kanagawa_bed = $_POST['kanagawa_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        kanagawa_infected = :kanagawa_infected,
                        kanagawa_injured = :kanagawa_injured,
                        kanagawa_bed = :kanagawa_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':kanagawa_infected', $kanagawa_infected, PDO::PARAM_INT); 
$stmt->bindValue(':kanagawa_injured', $kanagawa_injured, PDO::PARAM_INT);
$stmt->bindValue(':kanagawa_bed', $kanagawa_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('kanagawa.php');
}
