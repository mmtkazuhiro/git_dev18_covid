<?php
// select.phpの内容を一日分だけ表示させる


require_once('funcs.php');
$pdo = db_conn();

// GETで送られてきたidを取得する
$id = $_GET['id'];

//２．データ登録SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_c_table WHERE id = " . $id . ';');
$status = $stmt->execute();

//３．データ表示
if ($status == false) {
    // ここもfuncs.phpで関数化したsql_errorを使う
    sql_error($status);
} else {
    // 1個だけデータを取り出して$rowに格納する
    $row = $stmt->fetch();
}

?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/detail.css" rel="stylesheet">
    <title>北海道 コロナ感染状況 詳細画面</title>
</head>
<body>



    <form action="update_fukushima.php" method="POST">

        <div class="indate">登録日時：<?= $row['indate']; ?></div>
        
        <div class="exp">
        このページでは
            <li>それぞれの数値を訂正することができます (訂正)</li>
            <li>その登録日時時点の全国の感染状況を確認できます (表示)</li>
            <li>この登録自体を削除できます (削除)</li>
        </div>

        <table>
            <tr>
                <th>感染者</th>
                <td><input type="text" name="fukushima_infected" value="<?= $row['fukushima_infected']; ?>"></td>
            </tr>

            <tr>
                <th>重傷者</th>
                <td><input type="text" name="fukushima_injured" value="<?= $row['fukushima_injured']; ?>"></td>
            </tr>
            <tr>
                <th>病床数</th>
                <td><input type="text" name="fukushima_bed" value="<?= $row['fukushima_bed']; ?>"></td>
            </tr>
        </table>


        <input type="hidden" name="id" value="<?= $row['id']; ?>">

        <div class="btn">
            <div class="outfix">
                <input type="submit" value="訂正" class="fix">
            </div>

            <div class="outoutshow">
                <div class="outshow">
                    <a href="map.php?id=<?=$row['id']; ?>" class="show">表示</a>
                </div>
            </div>

            <div class="outoutdel">
                <div class="outdel">
                    <a href="delete_fukushima.php?id=<?=$row['id']; ?>" class="del">削除</a>
                </div>
            </div>
        </div>

    </form>
</body>
</html>