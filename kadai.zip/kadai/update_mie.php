<?php

require_once('funcs.php');

//1. POSTデータ取得
    $mie_infected = $_POST['mie_infected'];
    $mie_injured = $_POST['mie_injured'];
    $mie_bed = $_POST['mie_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        mie_infected = :mie_infected,
                        mie_injured = :mie_injured,
                        mie_bed = :mie_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':mie_infected', $mie_infected, PDO::PARAM_INT); 
$stmt->bindValue(':mie_injured', $mie_injured, PDO::PARAM_INT);
$stmt->bindValue(':mie_bed', $mie_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('mie.php');
}
