<?php

require_once('funcs.php');

//1. POSTデータ取得
    $ibaraki_infected = $_POST['ibaraki_infected'];
    $ibaraki_injured = $_POST['ibaraki_injured'];
    $ibaraki_bed = $_POST['ibaraki_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        ibaraki_infected = :ibaraki_infected,
                        ibaraki_injured = :ibaraki_injured,
                        ibaraki_bed = :ibaraki_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':ibaraki_infected', $ibaraki_infected, PDO::PARAM_INT); 
$stmt->bindValue(':ibaraki_injured', $ibaraki_injured, PDO::PARAM_INT);
$stmt->bindValue(':ibaraki_bed', $ibaraki_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('ibaraki.php');
}
