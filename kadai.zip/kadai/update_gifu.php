a<?php

require_once('funcs.php');

//1. POSTデータ取得
    $gifu_infected = $_POST['gifu_infected'];
    $gifu_injured = $_POST['gifu_injured'];
    $gifu_bed = $_POST['gifu_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        gifu_infected = :gifu_infected,
                        gifu_injured = :gifu_injured,
                        gifu_bed = :gifu_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':gifu_infected', $gifu_infected, PDO::PARAM_INT); 
$stmt->bindValue(':gifu_injured', $gifu_injured, PDO::PARAM_INT);
$stmt->bindValue(':gifu_bed', $gifu_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('gifu.php');
}
