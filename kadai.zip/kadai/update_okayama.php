<?php

require_once('funcs.php');

//1. POSTデータ取得
    $okayama_infected = $_POST['okayama_infected'];
    $okayama_injured = $_POST['okayama_injured'];
    $okayama_bed = $_POST['okayama_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        okayama_infected = :okayama_infected,
                        okayama_injured = :okayama_injured,
                        okayama_bed = :okayama_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':okayama_infected', $okayama_infected, PDO::PARAM_INT); 
$stmt->bindValue(':okayama_injured', $okayama_injured, PDO::PARAM_INT);
$stmt->bindValue(':okayama_bed', $okayama_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('okayama.php');
}
