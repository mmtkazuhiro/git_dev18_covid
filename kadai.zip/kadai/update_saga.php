<?php

require_once('funcs.php');

//1. POSTデータ取得
    $saga_infected = $_POST['saga_infected'];
    $saga_injured = $_POST['saga_injured'];
    $saga_bed = $_POST['saga_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        saga_infected = :saga_infected,
                        saga_injured = :saga_injured,
                        saga_bed = :saga_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':saga_infected', $saga_infected, PDO::PARAM_INT); 
$stmt->bindValue(':saga_injured', $saga_injured, PDO::PARAM_INT);
$stmt->bindValue(':saga_bed', $saga_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('saga.php');
}
