<?php

try {
    //Password:MAMP='root',XAMPP=''
    $pdo = new PDO('mysql:dbname=gs_kadai2;charset=utf8;host=localhost','root','root');
  } catch (PDOException $e) {
    exit('DBConnectError'.$e->getMessage());
  }

$view = intval($pdo->query("SELECT * FROM gs_c_table WHERE id = (SELECT max(id) FROM gs_c_table)")->fetchColumn());
$aomori_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$iwate_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$miyagi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$akita_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$yamagata_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$fukushima_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$ibaraki_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$tochigi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$gunma_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$saitama_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$chiba_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$tokyo_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kanagawa_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$niigata_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$toyama_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$ishikawa_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$fukui_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$yamanashi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$nagano_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$gifu_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$shizuoka_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$aichi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$mie_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$shiga_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kyoto_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$osaka_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$hyogo_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$nara_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$wakayama_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$tottori_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$shimane_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$okayama_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$hiroshima_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$yamaguchi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$tokushima_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kagawa_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$ehime_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kochi_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$fukuoka_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$saga_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$nagasaki_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kumamoto_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$oita_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$miyazaki_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$kagoshima_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
$okinawa_infected = intval($pdo->query("SELECT max(id) FROM gs_c_table")->fetchColumn());
