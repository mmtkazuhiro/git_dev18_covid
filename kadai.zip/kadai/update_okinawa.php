<?php

require_once('funcs.php');

//1. POSTデータ取得
    $okinawa_infected = $_POST['okinawa_infected'];
    $okinawa_injured = $_POST['okinawa_injured'];
    $okinawa_bed = $_POST['okinawa_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        okinawa_infected = :okinawa_infected,
                        okinawa_injured = :okinawa_injured,
                        okinawa_bed = :okinawa_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':okinawa_infected', $okinawa_infected, PDO::PARAM_INT); 
$stmt->bindValue(':okinawa_injured', $okinawa_injured, PDO::PARAM_INT);
$stmt->bindValue(':okinawa_bed', $okinawa_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('okinawa.php');
}
