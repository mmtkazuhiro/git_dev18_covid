<?php

require_once('funcs.php');

//1. POSTデータ取得
    $miyagi_infected = $_POST['miyagi_infected'];
    $miyagi_injured = $_POST['miyagi_injured'];
    $miyagi_bed = $_POST['miyagi_bed'];
    $id = $_POST["id"];
    

    //2. DB接続
$pdo = db_conn();


//３．データ登録SQL作成
$stmt = $pdo->prepare("UPDATE 
                        gs_c_table 
                    SET 
                        miyagi_infected = :miyagi_infected,
                        miyagi_injured = :miyagi_injured,
                        miyagi_bed = :miyagi_bed
                        WHERE
                        id = :id;
                        ");

$stmt->bindValue(':miyagi_infected', $miyagi_infected, PDO::PARAM_INT); 
$stmt->bindValue(':miyagi_injured', $miyagi_injured, PDO::PARAM_INT);
$stmt->bindValue(':miyagi_bed', $miyagi_bed, PDO::PARAM_INT);
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$status = $stmt->execute();


//４．データ登録処理後
if($status==false){
    sql_error($stmt);
}else{
    // redirectも関数化しているので、これでOK
    redirect('miyagi.php');
}
